import os
import glob
import time
import array
import pickle
import gzip
from .settings import DataKey
from .parse import parse
from .model import model

GZIP_LEVEL = 2

class LafException(Exception):
    def __init__(self, message, stamp, Errors):
        Exception.__init__(self, message)
        stamp.Emsg(message)
        raise

class LafData(object):
    '''Manage the compiling and loading of LAF/GraF data.'''

    def __init__(self):
        self.log = None
        self.data_items = {}

    def adjust_all(self, source, annox, task, req_items, prepared_dict, force):
        '''Load manager.

        Load and clear data so that the current task has all it needs and no more.
        Compile outdated binary data just before loading.
        '''
        self.settings.setenv(source, annox, task)
        env = self.settings.env
        try:
            if not os.path.exists(env['main_compiled_dir']): os.makedirs(env['main_compiled_dir'])
        except os.error:
            raise LafException("could not create bin directory {}".format(env['main_compiled_dir']), self.stamp, os.error)
        if annox != env['empty']:
            try:
                if not os.path.exists(env['annox_compiled_dir']): os.makedirs(env['annox_compiled_dir'])
            except os.error:
                raise LafException("could not create bin directory {}".format(env['annox_compiled_dir']), self.stamp, os.error)
        try:
            if not os.path.exists(env['task_dir']): os.makedirs(env['task_dir'])
        except os.error:
            raise LafException("could not create result directory {}".format(env['task_dir']), self.stamp, os.error)
        correct = True
        if not self._compile_all(force): correct = False
        if not self._load_all(req_items, prepared_dict): correct = False
        self._add_logfile()
        return correct

    def finish_task(self, show=True):
        '''Close all opne files that have been opened by the API'''
        task_dir = self.settings.env['task_dir']
        for handle in self.result_files:
            if handle and not handle.closed: handle.close()
        self.result_files = []
        self._flush_logfile()
        mg = []
        if show:
            self.stamp.Nmsg("Results directory:\n{}".format(task_dir))
            for name in sorted(os.listdir(path=task_dir)):
                path = "{}/{}".format(task_dir, name) 
                size = os.path.getsize(path)
                mtime = time.ctime(os.path.getmtime(path))
                mg.append("{:<30} {:>12} {}".format(name, size, mtime))
            self.stamp.Nmsg("\n" + "\n".join(mg), withtime=False)
        self._finish_logfile()

    def _finish_logfile(self):
        try: self.log.close()
        except: pass
        self.stamp.disconnect_log()
        self.log = None

    def _flush_logfile(self):
        try: self.log.flush()
        except: pass

    def _add_logfile(self, compile=None):
        env = self.settings.env
        log_dir = env['task_dir'] if compile == None else env["{}_compiled_dir".format(compile)]
        log_path = env['log_path'] if compile == None else env["{}_compiled_path".format(compile)]
        try:
            if not os.path.exists(log_dir): os.makedirs(log_dir)
        except os.error:
            raise LafException("could not create log directory {}".format(log_dir), self.stamp, os.error)
        self.log = open(log_path, "w", encoding="utf-8")
        self.stamp.connect_log(self.log)
        self.stamp.Nmsg("LOGFILE={}".format(log_path))

    def _compile_all(self, force):
        env = self.settings.env
        compile_uptodate = {}
        compile_uptodate['main'] = not os.path.exists(env['main_source_path']) or (
                os.path.exists(env['main_compiled_path']) and
                os.path.getmtime(env['main_compiled_path']) >= os.path.getmtime(env['main_source_path'])
            )

        uptodate = True
        for afile in glob.glob('{}/*.xml'.format(env['annox_source_dir'])):
            this_uptodate = env['annox'] == env['empty'] or (
                os.path.exists(env['annox_compiled_path']) and
                os.path.getmtime(env['annox_compiled_path']) >= os.path.getmtime(afile)
            )
            if not this_uptodate:
                uptodate = False
                break
        compile_uptodate['annox'] = uptodate
        has_compiled = False
        for origin in ['main', 'annox']:
            if not compile_uptodate[origin] or force[origin]:
                self.stamp.Nmsg("BEGIN COMPILE {}: {}".format(origin, env['source'] if origin == 'main' else env['annox']))
                self._clear_origin(origin)
                if origin == 'annox': self._load_all({'X': ['node', 'edge']}, {}, extra=True)
                self._compile_origin(origin)
                has_compiled = True
                self.stamp.Nmsg("END   COMPILE {}: {}".format(origin, env['source'] if origin == 'main' else env['annox']))
            else: self.stamp.Dmsg("COMPILING {}: UP TO DATE".format(origin))
        if has_compiled:
            self._clear_origin(origin)
            self.settings.setenv(env['source'], env['annox'], env['task'])

    def _compile_origin(self, origin):
        env = self.settings.env
        the_log_file = env['compiled_file']
        the_log_dir = env['{}_compiled_dir'.format(origin)]
        self._add_logfile(compile=origin)
        self._parse(origin)
        self._model(origin)
        self._store_origin(origin)
        self._finish_logfile()

    def _clear_origin(self, origin):
        for dkey in self.data_items:
            (d, start, end, comps) = DataKey.decomp(dkey)
            if (origin == 'annox' and start == 'annox') or origin != 'annox': self._clear_file(dkey)

    def _clear_file(self, dkey):
        if dkey in self.data_items[dkey]: del self.data_items[dkey]

    def _load_all(self, req_items, prepared_dict, extra=False):
        datakey = self.settings.datakey
        datakey.request_files(req_items, extra=extra)
        old_data_items = datakey.old_data_items
        new_data_items = datakey.data_items
        correct = True
        prep_items = set()
        for dkey in old_data_items:
            if dkey not in new_data_items or new_data_items[dkey][0] != old_data_items[dkey][0]:
                self.stamp.Dmsg("clear {}".format(DataKey.dmsg(dkey))) 
                self._clear_file(dkey)
        for dkey in new_data_items:
            (d, start, end, comps) = DataKey.decomp(dkey)
            if dkey in old_data_items and new_data_items[dkey][0] == old_data_items[dkey][0]:
                self.stamp.Dmsg("keep {}".format(DataKey.dmsg(dkey))) 
            else:
                (dpath, dtype, dprep) = new_data_items[dkey]
                if dprep:
                    prep_items.add(dkey)
                    continue
                this_correct = self._load_file(dkey, prepared_dict, accept_missing=start=='annox')
                if not this_correct: correct = False
        for dkey in prep_items:
            (d, start, end, comps) = DataKey.decomp(dkey)
            this_correct = self._load_file(dkey, prepared_dict, accept_missing=start=='annox')
            if not this_correct: correct = False
        return correct

    def _load_file(self, dkey, prepared_dict, accept_missing=False):
        datakey = self.settings.datakey
        data_items = datakey.data_items
        self.stamp.Dmsg("load {}".format(DataKey.dmsg(dkey))) 
        (dpath, dtype, dprep) = data_items[dkey]
        if dprep:
            if dkey not in prepared_dict:
                self.stamp.Wmsg("Cannot prepare data for {}. No preparation method available {}.".format(DataKey.dmsg(dkey), dkey))
                return False
            (method, method_source) = prepared_dict[pkey]
            up_to_date = os.path.exists(dpath) and os.path.getmtime(dpath) >= os.path.getmtime(method_source)
            if not up_to_date:
                self.stamp.Dmsg("PREPARING {}".format(DataKey.dmsg(dkey)))
                newdata = method(api)
                self.stamp.Dmsg("WRITING {}".format(DataKey.dmsg(dkey)))
                self.data_items[dkey] = newdata
                self._store_file(dkey)
                return True
        if not os.path.exists(dpath):
            if not accept_missing:
                self.stamp.Emsg("Cannot load data for {}: File does not exist: {}.".format(DataKey.dmsg(dkey), dpath))
            return accept_missing
        newdata = None
        if dtype == 'arr':
            newdata = array.array('I')
            handle = gzip.open(dpath, "rb")
            contents = handle.read()
            handle.close
            newdata.frombytes(contents)
        elif dtype == 'dct':
            handle = gzip.open(dpath, "rb")
            newdata = pickle.load(handle)
            handle.close()
        elif dtype == 'str':
            handle = gzip.open(dpath, "rt", encoding="utf-8")
            newdata = handle.read(None)
            handle.close()
        self.data_items[dkey] = newdata
        return True

    def _store_origin(self, origin):
        self.stamp.Nmsg("WRITING RESULT FILES for {}".format(origin))
        data_items = self.data_items
        for dkey in data_items:
            (d, start, end, comps) = DataKey.decomp(dkey)
            if (origin == 'annox' and start == 'annox') or origin != 'annox': self._store_file(dkey)

    def _store_file(self, dkey):
        datakey = self.settings.datakey
        data_items = datakey.data_items
        (dpath, dtype, dprep) = datakey.dinfo(dkey)
        if dpath == None:
            return
        thedata = self.data_items[dkey]
        self.stamp.Dmsg("write {}".format(DataKey.dmsg(dkey))) 
        if dtype == 'arr':
            handle = gzip.open(dpath, "wb", compresslevel=GZIP_LEVEL)
            thedata.tofile(handle)
            handle.close()
        elif dtype == 'dct':
            handle = gzip.open(dpath, "wb", compresslevel=GZIP_LEVEL)
            pickle.dump(thedata, handle)
            handle.close()
        elif dtype == 'str':
            handle = gzip.open(dpath, "wt", encoding="utf-8")
            handle.write(thedata)
            handle.close()
        return True

    def _parse(self, origin):
        self.stamp.Nmsg("PARSING ANNOTATION FILES")
        env = self.settings.env
        source_dir = env['{}_source_dir'.format(origin)]
        source_path = env['{}_source_path'.format(origin)]
        compiled_dir = env['{}_compiled_dir'.format(origin)]
        self.cur_dir = os.getcwd()
        if not os.path.exists(source_path):
            raise LafException("LAF header does not exists {}".format(source_path), self.stamp, os.error)
        try:
            os.chdir(source_dir)
        except os.error:
            raise LafException("could not change to LAF source directory {}".format(source_dir), self.stamp, os.error)
        try:
            if not os.path.exists(compiled_dir): os.makedirs(compiled_dir)
        except os.error:
            os.chdir(self.cur_dir)
            raise LafException("could not create directory for compiled source {}".format(compiled_dir), self.stamp, os.error)
        parse(
            origin,
            env['{}_source_path'.format(origin)],
            self.stamp,
            self.data_items,
        )
        os.chdir(self.cur_dir)

    def _model(self, origin):
        self.stamp.Nmsg("MODELING RESULT FILES")
        datakey = self.settings.datakey
        data_items = datakey.data_items
        data_items_def = datakey.data_items_def
        model(origin, self.data_items, self.stamp)

    def __del__(self):
        self.stamp.Nmsg("END")
        for handle in (self.log,):
            if handle and not handle.closed: handle.close()

