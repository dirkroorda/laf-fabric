import sys
import os
import collections
import configparser

MAIN_CFG = 'laf-fabric.cfg'
VERSION = '3.7.0'

class DataKey(object):
    '''Manage the names of compiled LAF data items.

    Data items are stored in a dictionary with keys in the shape of a prefix with components,
    comma-separated.

    **Prefixes**:
    ``P``: primary data items,
    ``G``: items for regions, nodes, edges, 
    ``X``: xml identifiers,
    ``F``: features,
    ``C``: connectivity,
    ``Q``: not prepared by Laf-Fabric but byauxiliary models,
    ``T``: temporary during compiling.

    Some prefixes have a prefix ``A`` indicating data from an *annox*, not the *main* source.
    Some prefixes have a prefix ``R`` indicating a direction from integer to representation, not from representation to integers.
    Some prefixes have a postfix ``E``, indicating data for *edges*, not *nodes*.
    Some prefixes have postfix ``i``, indicating an inverse direction of edges.

    **Components**:
    There are multiple features, each feature is a component. Also the ``node_anchor`` things are components.
    For each key there is information: a path name, a condition, a data type.
    The condition is a key in a dictionary of conditions.
    The loader determines the condition dictionary by filling in these slots with relevant components.

    **Class methods**
    Several class methods take care for the composition and decomposition of keys and prefixes and components.

    **Instance data and methods**
    The instance data contains a compiled list of datakeys, adapted to the present environment, which is based
    on the source, annox and task chosen by the user.
    The previous list is also remembered, so that the loader can load/unload the difference.
    The method ``request_files`` does this.
    '''
    _data_items_template = ( 
        ('P,node_anchor',        '{bin_dir}/{source}/P,node_anchor'       , 'P', 'arr'),
        ('P,node_anchor_items',  '{bin_dir}/{source}/P,node_anchor_items' , 'P', 'arr'),
        ('G,node_anchor_min',    '{bin_dir}/{source}/G,node_anchor_min'   , 'G', 'arr'),
        ('G,node_anchor_max',    '{bin_dir}/{source}/G,node_anchor_max'   , 'G', 'arr'),
        ('P,node_events',        '{bin_dir}/{source}/P,node_events'       , 'P', 'arr'),
        ('P,node_events_items',  '{bin_dir}/{source}/P,node_events_items' , 'P', 'arr'),
        ('P,node_events_k',      '{bin_dir}/{source}/P,node_events_k'     , 'P', 'arr'),
        ('P,node_events_n',      '{bin_dir}/{source}/P,node_events_n'     , 'P', 'arr'),
        ('G,node_sort',          '{bin_dir}/{source}/G,node_sort'         , 'G', 'arr'),
        ('G,node_sort_inv',      '{bin_dir}/{source}/G,node_sort_inv'     , 'G', 'dct'),
        ('G,edges_from',         '{bin_dir}/{source}/G,edges_from'        , 'G', 'arr'),
        ('G,edges_to',           '{bin_dir}/{source}/G,edges_to'          , 'G', 'arr'),
        ('P,primary_data',       '{bin_dir}/{source}/P,primary_data'      , 'P', 'str'),
        ('X',                    '{bin_dir}/{source}/X'                   , 'X', 'dct'),
        ('XE',                   '{bin_dir}/{source}/XE'                  , 'XE', 'dct'),
        ('RX',                   '{bin_dir}/{source}/RX'                  , 'X', 'dct'),
        ('RXE',                  '{bin_dir}/{source}/RXE'                 , 'XE', 'dct'),
        ('F',                    '{bin_dir}/{source}/F'                   , 'F', 'dct'),
        ('FE',                   '{bin_dir}/{source}/FE'                  , 'E', 'dct'),
        ('C',                    '{bin_dir}/{source}/C'                   , 'E', 'dct'),
        ('Ci',                   '{bin_dir}/{source}/Ci'                  , 'E', 'dct'),
        ('AF',                   '{bin_dir}/{source}/A/{annox}/F'         , 'AF', 'dct'),
        ('AFE',                  '{bin_dir}/{source}/A/{annox}/FE'        , 'AE', 'dct'),
        ('AC',                   '{bin_dir}/{source}/A/{annox}/C'         , 'AE', 'dct'),
        ('ACi',                  '{bin_dir}/{source}/A/{annox}/Ci'        , 'AE', 'dct'),
        ('Q,node_resorted',      '{bin_dir}/{source}/Q,node_resorted'     , 'Q', 'arr'),
        ('Q,node_resorted_inv',  '{bin_dir}/{source}/Q,node_resorted_inv' , 'Q', 'arr'),
    )
    _trans = {
        'X': ('X', 'int', 'node'),
        'XE': ('X', 'int', 'edge'),
        'RX': ('X', 'rep', 'node'),
        'RXE': ('X', 'rep', 'edge'),
        'F': ('F', 'main', 'node'),
        'FE': ('F', 'main', 'edge'),
        'AF': ('F', 'annox', 'node'),
        'AFE': ('F', 'annox', 'edge'),
        'C': ('C', 'main', False),
        'Ci': ('C', 'main', True),
        'AC': ('C', 'annox', False),
        'ACi': ('C', 'annox', True),
        'Q': ('Q', None, None),
        'G': ('G', None, None),
        'P': ('P', None, None),
        'T': ('T', None, None),
    }

    edge_has_annots = 'y'
    edge_has_no_annots = 'x'

    _transback = dict([(i[1], i[0]) for i in _trans.items()]) 
    _dkey2group = dict([(x[1], x[0]) for x in [y.split(',') for y in [z[0] for z in _data_items_template if ',' in z[0]]]]) 

    def __init__(self):
        self.data_items_def = collections.OrderedDict()
        self.data_items = collections.OrderedDict()
        self.old_data_items = collections.OrderedDict()

    def update(self, env):
        for t in self._data_items_template: self.data_items_def[t[0]] = (t[1].format(**env), t[2], t[3])

    def apiname(feature): return "_".join(feature)
    def comp(p, things): return DataKey.comp_plain(DataKey.comp_pref(p), things)
    def comp_plain(p, things): return ",".join((p,) + things)
    def comp_pref(p): return DataKey._transback[p]
    def comp_item(istr): return ",".join((DataKey.dkey2group(istr), istr))

    def dinfo(self, dkey):
        (d, start, end, comps) = DataKey.decomp(dkey)
        if d == '' or d == 'T':
            return (None, None, None)
        elif d in 'XFC':
            (dpath_pre, docc, dtype) = self.data_items_def[DataKey.comp_pref((d, start, end))] 
            dpath = DataKey.comp_plain(dpath_pre, comps)
        else: (dpath, docc, dtype) = self.data_items_def[dkey]
        return (dpath, dtype, docc == 'Q')

    def decomp(s):
        if ',' not in s: return ('', None, None, None)
        comps = s.split(',')
        return DataKey._trans[comps[0]] + (tuple(comps[1:]),)

    def dkey2group(istr):
        if istr in DataKey._dkey2group: return DataKey._dkey2group[istr]
        return 'T'

    def dmsg(s):
        (d, start, end, comps) = DataKey.decomp(s) 
        return "{}{}.{}{}".format(
            "{}:".format(start) if start else '',
            d,
            '_'.join(comps),
            " ({})".format(end) if end else '',
        )

    def print_all(self):
        for dkey in self.data_items: print(DataKey.dmsg(dkey))

    def request_files(self, req_items, extra=False):
        self.old_data_items = self.data_items
        self.data_items = collections.OrderedDict()
        if extra: self.data_items.update(self.old_data_items)
        for dkey in self.data_items_def:
            (dpath, docc, dtype) = self.data_items_def[dkey]
            self.data_items.update(DataKey._multiply_req(dkey, dpath, dtype, docc, req_items))

    def _multiply_req(dkey, dpath, dtype, docc, req_items):
        if docc not in req_items: return {}
        result = {}
        if req_items[docc] == True:
            result[dkey] = (dpath, dtype, docc == 'Q')
        elif req_items[docc] == False: pass
        else:
            for item in req_items[docc]:
                result[DataKey.comp_plain(dkey, item)] = (DataKey.comp_plain(dpath, item), dtype, docc == 'Q')
        return result

class Settings(object):
    '''Manage the configuration.

    The directory structure is built as a set of names in an environment dictionary. 
    The method ``setenv`` builds a new structure based on user choices.
    Local settings can be passed as arguments to object creation, or in a config file in the current directory,
    or in a config file in the user's home directory.
    It is possible to save these settings in the latter config file.
    '''
    _myconfig = {
        'work_dir': None,                      # working directory (containing compiled laf, task results)
        'main_source_dir': None,               # directory containing original, uncompiled laf resource
        'main_source_subdir': 'laf',           # subdirectory of main laf resource
        'annox_source_subdir': 'annotations',  # subdirectory of annotation add-ons
        'bin_subdir': 'bin',                   # subdirectory of compiled data
        'task_subdir': 'tasks',                # subdirectory of task results
        'bin_ext': 'bin',                      # file extension for binary files
        'text_ext': 'txt',                     # file extension for text files
        'log_name': '__log__',                 # base name for log files
        'compile_name': 'compile__',           # extension name for log files of compile process
        'primary_data': 'primary_data',        # name of the primary data file in the compiled data
        'empty': '--',                         # name of empty annox
        'header': '_header_.xml',              # name of laf header file in annox
    }
    _env_def = {
        'source':                '{source}',
        'annox':                 '{annox}',
        'task':                  '{task}',
        'empty':                 '{empty}',
        'work_dir':              '{work_dir}',
        'bin_dir':               '{work_dir}/{bin_subdir}',
        'main_source_dir':       '{main_source_dir}',
        'main_source_path':      '{main_source_dir}/{source}',
        'annox_source_dir':      '{main_source_dir}/{annox_source_subdir}/{annox}',
        'annox_source_path':     '{main_source_dir}/{annox_source_subdir}/{annox}/{header}',
        'compiled_file':         '{log_name}{compile_name}.{text_ext}',
        'main_compiled_dir':     '{work_dir}/{bin_subdir}/{source}',
        'main_compiled_path':    '{work_dir}/{bin_subdir}/{source}/{log_name}{compile_name}.{text_ext}',
        'primary_compiled_path': '{work_dir}/{bin_subdir}/{source}/{primary_data}',
        'annox_compiled_dir':    '{work_dir}/{bin_subdir}/{source}/A/{annox}',
        'annox_compiled_path':   '{work_dir}/{bin_subdir}/{source}/A/{annox}/{log_name}{compile_name}.{text_ext}',
        'task_dir':              '{work_dir}/{task_subdir}/{source}/{task}',
        'log_path':              '{work_dir}/{task_subdir}/{source}/{task}/{log_name}{task}.{text_ext}',
    }

    def __init__(self, work_dir, laf_dir, save):
        sys.stderr.write('This is LAF-Fabric {}\n'.format(VERSION))
        config_path = None
        home_config_path = "{}/{}".format(os.path.expanduser('~'), MAIN_CFG)
        if os.path.exists(MAIN_CFG): config_path = MAIN_CFG
        else:
            if os.path.exists(home_config_path): config_path = home_config_path
        strings = configparser.ConfigParser(inline_comment_prefixes=('#'))
        strings.read_file(open(config_path, "r", encoding="utf-8"))
        config_work_dir = None
        config_laf_dir = None
        if 'locations' in strings:
            if 'work_dir' in strings['locations']: config_work_dir = strings['locations']['work_dir']
            if 'laf_dir' in strings['locations']: config_laf_dir = strings['locations']['laf_dir']
        if work_dir == None: work_dir = config_work_dir
        if laf_dir == None: laf_dir = config_laf_dir
        if work_dir == None:
            print("ERROR: No data directory given (looked for arguments, {}, and {}.".format(MAIN_CFG, home_config_dir))
        elif not os.path.exists(work_dir):
            print("ERROR: Given data directory {} does not exist.".format(work_dir))
            work_dir = None
        if work_dir == None: sys.exit(1)
        if laf_dir == None:
            print("WARNING: No original laf directory given (looked for arguments, {}, and {}.".format(MAIN_CFG, home_config_dir))
        elif not os.path.exists(laf_dir):
            print("WARNING: Given original laf directory {} does not exist.".format(laf_dir))
            laf_dir = None
        self._myconfig['work_dir'] = work_dir
        self._myconfig['main_source_dir'] = laf_dir
        if save and work_dir != None:
            strings['locations'] = {
                'work_dir': work_dir,
                'laf_dir': laf_dir,
            }
            config_path = home_config_path
            strings.write(open(home_config_path, 'w', encoding= 'utf-8'))
        self.env = {}
        self.datakey = DataKey()

    def setenv(self, source, annox, task):
        for e in self._env_def: self.env[e] = self._env_def[e].format(source=source, annox=annox, task=task, **self._myconfig)
        self.datakey.update(self.env)
